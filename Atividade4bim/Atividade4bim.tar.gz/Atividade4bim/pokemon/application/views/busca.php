<div id="homebody">
		<h2>Pokemons</h2>
		<div class ="centralizar border-bot espacamento">


    </tr>

      <h3> Exibindo resultados para " <?php echo $termo  ?>" </h3>
      <p> Sua pesquisa retornou os seguintes resultados: </p>
  	</div>
  	<div class="row-fluid">
			<table class="table">
    <thead>
      <tr>
				<th>Id</th>
        <th>Nome</th>
        <th>Tipo</th>
        <th>Data de Captura</th>

      </tr>
    </thead>
    <tbody>


      <tr class="default">
				<?php
              $cont=0;
              foreach($pk as $pkm) {
                $cont++;
                      echo "<tr>";
											echo "<td>".$pkm->id_pokemon."</td>";
                      echo "<td>".$pkm->nome."</td>";
                      echo "<td>".$pkm->tipo_pokemon."</td>";
                      echo "<td>".$pkm->data_captura."</td>";

                     }
                  ?>

      </tr>

    </tbody>
  </table>
</div>
  </div>
 </div>
