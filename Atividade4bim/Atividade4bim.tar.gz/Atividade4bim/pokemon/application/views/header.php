<div class="container">
	<div class ="masthead">

			<h3>Boguemao <span class="label label-primary">gol</span></h3><br>
			<nav class="navbar navbar-default">

		  <ul class="nav navbar-nav">
			  <li class="active"><a href="http://localhost/Atividade4bim/pokemon/index.php/Home">Boguemoes</a></li>
				<li><a href="http://localhost/Atividade4bim/pokemon/index.php/Cadastro">Novo Boguemao</a></li>
				<form class="navbar-form navbar-left">
					 <div class="form-group">
						 <input type="text" name="txt_busca"class="form-control" placeholder="Search">
					 </div>
					 <a href="http://localhost/Atividade4bim/pokemon/index.php/Home/pesquisar"><button type="button" class="btn btn-default">Buscar</button></a>
		 	 </form>

			  <ul class="nav navbar-nav navbar-right">
					<?php echo "<li><a>". $this->session->userdata('usuario')->nome." "."</a></li>"
	?>
					<li><a href="http://localhost/Atividade4bim/pokemon/index.php/Login/sair">Sair</a></li>
			 </ul>

		 </ul>
	 </nav>

  </div>
