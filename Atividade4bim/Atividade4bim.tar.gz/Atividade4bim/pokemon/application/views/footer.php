<div class ="alinhado-centro borda-base espaco-vertical">
<div id="footer" class="border-top espacamento">
  <i class="fa fa-dot-circle-o">BOGUEMAO! GARA KETCHEMAL</i>
  </div>
  </div>
