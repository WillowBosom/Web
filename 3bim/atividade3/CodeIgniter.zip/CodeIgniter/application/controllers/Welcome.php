<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 
	public function index(){
		//$this->load->view('welcome_message');
		$data['mensagem'] = "Olá mundo!!";
		$this->load->view('ola_mundo', $data);
	}
	*/
	public function index(){
		
		
		$this->load->view('menu');
	}
	
	public function detalhes($id){
		
		$this->db->where('id', $id);
		/*$data['postagem'] = $this->db->get('postagens')->result();
		$data['postagens'] = $this->db->get('postagens')->result();*/
		$this->load->view('detalhes_postagem', $data);
	}
	
	public function novo_registro(){
		
		$this->load->helper('form');
		$this->load->view('novo_registro');
	}
	
	public function enviar_dados (){
		
		$data['nomeArquivo'] = $this->input->post('txt_nome');
		$data['titulo'] = $this->input->post('txt_titulo');
		$data['autores'] = $this->input->post('txt_autores');
		$data['citacoes'] = $this->input->post('txt_citacoes');
		$data['palavraChave'] = $this->input->post('txt_palavras');
		$data['referencias'] = $this->input->post('txt_referencias');
		if($this->db->insert('citacoes', $data)){
			redirect(base_url('menu'));
		}else{
			echo "Erro";
		}
		
		/*$dados = "Nome do Arquivo: " . $this->input->post('txt_nome') . br();
		$dados .= "Título: " . $this->input->post('txt_titulo') . br();
		$dados .= "Autores: " . $this->input->post('txt_autores') . br();
		$dados .= "Citações:" . $this->input->post('txt_citacoes') . br();
		$dados .= "Palavras-Chave" . $this->input->post('txt_palavras') . br();
		$dados .= "Referências" . $this->input->post('txt_referencias') . br();
		$config['protocol'] = 'smtp';
		$config['smtp_host'] = 'ssl://smtp.live.com';
		$config['smtp_port'] = '587';
		$config['smtp_timeout'] = '30';
		$config['smtp_user'] = 'ccnsassino1998@hotmail.com'; /*mandar email pro caiao*//*
		$config['smtp_pass'] = 'caiaio98.com';
		$config['charset'] = 'utf-8';
		$config['newline'] = "\r\n";
		$config['mailtype'] = 'html';
		$this->load->library('email', $config) ;
		$this->email->from("ccnsassino1998@hotmail.com","Formulário do website") ;
		$this->email->to("ccnsassino1998@hotmail.com");
		$this->email->subject('Assunto do e-mail, enviado pelo CodeIgniter') ;
		$this->email->message($mensagem);
		
		if($this->email->send()){
			
			$this->load->view('sucesso_envia_contato');
		}else{
			
			print_r($this->email->print_debugger());
		}*/
	}
	
	public function error404(){
		
		$this->load->view('error404');
	}
	
}
