<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {


	public function index(){
		
		
		$this->load->view('menu');
	}
	
	public function detalhes($id){
		
		$this->db->where('id', $id);
		$this->load->view('detalhes_postagem', $data);
	}
	
	public function novo_registro(){
		
		$this->load->helper('form');
		$this->load->view('novo_registro');
	}
	
	public function enviar_dados (){
		
		$data['nomeArquivo'] = $this->input->post('txt_nome');
		$data['titulo'] = $this->input->post('txt_titulo');
		$data['autores'] = $this->input->post('txt_autores');
		$data['citacoes'] = $this->input->post('txt_citacoes');
		$data['palavrasChave'] = $this->input->post('txt_palavras');
		$data['referencias'] = $this->input->post('txt_referencias');
		if($this->db->insert('citacoes', $data)){
			redirect(base_url(''));
		}else{
			echo "Erro";
		}
	}
	
	public function relatorio() {
		$data['citacoes'] = $this->db->get('citacoes')->result();
		$this->load->view('relatorio', $data);
	}
	
	public function error404(){
		
		$this->load->view('error404');
	}
	
}
